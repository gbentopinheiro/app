# Bentix Deployment

## Requisitos

- Node.js compativel com Next.js 16
- MySQL ou MariaDB acessivel
- `DATABASE_URL` valida
- `BENTIX_DATA_SOURCE=mysql`

Para o alvo atual, MySQL deve ser tratado como obrigatorio.

## Variaveis de Ambiente Principais

- `BENTIX_DATA_SOURCE`
- `DATABASE_URL`
- `NODE_ENV`
- `LOGIN_PUBLIC_KEY_PEM`
- `LOGIN_PRIVATE_KEY_PEM`

Notas:

- em desenvolvimento, a chave de transporte de login pode ser gerada automaticamente
- em producao, `LOGIN_PUBLIC_KEY_PEM` e `LOGIN_PRIVATE_KEY_PEM` devem estar definidas

## Build e Start

Fluxo minimo:

```bash
npm install
npm run db:generate
npm run build
npm run start
```

Validacoes recomendadas antes de publicar:

```bash
npm run db:validate:mysql
npm run test:critical
npm run build
```

## Swagger / OpenAPI

Em deploy, a documentacao fica disponivel em:

- `/api/docs/openapi.json`
- `/developer/api-docs`

## Notas de Runtime

- a app e um monolito Next.js; frontend e API correm juntos
- o acesso a MySQL passa por Prisma
- rotas legacy de ficheiro continuam a existir no repositorio, pelo que storage local nao deve ser tratado como fonte principal de producao

## Notas Para Futura Separacao do Backend

Pontos a reaproveitar:

- `server/controllers`
- `server/services`
- `lib/db`
- contratos OpenAPI e contratos HTTP ja estabilizados

O passo natural e extrair a camada HTTP de `app/api/**` para um backend dedicado, sem rebentar os contratos atuais.

## Notas Para Cloud / Hosting

- usar MySQL gerido ou instancia persistente
- guardar variaveis de ambiente num secret manager
- validar politicas de ficheiros locais, porque alguns fluxos legacy ainda assumem filesystem
- manter logs, backups e health checks fora da app antes de separar o backend
